# 无人机管理 API

## REST 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/drones | 查询全部无人机 |
| GET | /api/drones/{id} | 查询无人机详情 |

## 页面接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /drone/list | 列表页 |
| GET | /drone/add | 新增页 |
| GET | /drone/edit/{id} | 编辑页 |
| POST | /drone/save | 保存 |
| POST | /drone/delete/{id} | 删除 |

## 数据库切换

- SQLite（默认）：`spring.profiles.active=sqlite`
- MySQL：`spring.profiles.active=mysql`
