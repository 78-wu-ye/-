# 无人机信息管理 - 产品需求规格

## 概述

基于 Spring Boot 平台，提供无人机信息的录入、查询、修改、删除功能，初期使用 SQLite 数据库。

## 功能需求

| 编号 | 功能 | 描述 |
|------|------|------|
| FR-01 | 列表查询 | 分页/列表展示全部无人机信息 |
| FR-02 | 新增录入 | 表单录入无人机属性并保存 |
| FR-03 | 修改信息 | 按 ID 编辑并更新无人机 |
| FR-04 | 删除信息 | 按 ID 删除无人机记录 |
| FR-05 | 数据库切换 | 支持 SQLite 与 MySQL，通过 Profile 切换 |

## 无人机属性（AI 生成）

| 字段 | 说明 |
|------|------|
| droneCode | 无人机编号 |
| model | 型号 |
| manufacturer | 制造商 |
| maxFlightTime | 最大飞行时间（分钟） |
| maxRange | 最大航程（公里） |
| maxAltitude | 最大飞行高度（米） |
| weight | 重量（千克） |
| cameraType | 摄像头类型 |
| batteryCapacity | 电池容量（mAh） |
| status | 状态：AVAILABLE/MAINTENANCE/RETIRED |
| purchaseDate | 采购日期 |
| remark | 备注 |

## 非功能需求

- 四层架构：controller / service / domain / repository
- 服务层与数据层接口与实现分离
- 独立 interceptor 包打印请求日志
- 视图层使用 Thymeleaf + Bootstrap 3.3.7
