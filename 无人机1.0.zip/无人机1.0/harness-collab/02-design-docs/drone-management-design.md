# 无人机信息管理 - 技术设计

## 技术栈

| 层次 | 技术 |
|------|------|
| 框架 | Spring Boot 3.2.x（兼容 JDK 21） |
| 安全 | Apache Shiro 2.x |
| 持久层 | MyBatis 3.5.x + Druid 1.2.x |
| 校验 | Hibernate Validation |
| 视图 | Thymeleaf 3.x + Bootstrap 3.3.7 |

## 包结构

```
com.md.basePlatform
├── config          # 数据源、MyBatis、Shiro、WebMvc
├── interceptor     # 请求日志拦截器
├── controller      # 页面与 API 控制器
├── service         # 业务接口
│   └── impl        # 业务实现
├── repository      # 数据访问接口
│   ├── mapper      # MyBatis Mapper
│   └── impl        # Repository 实现
├── domain          # 实体与表单对象
├── common          # 常量与工具
└── exception       # 异常与全局处理
```

## 数据库

- 默认 Profile：`sqlite`，数据文件 `./data/drone.db`
- 切换 MySQL：`spring.profiles.active=mysql`

## 接口设计

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /drone/list | 列表页 |
| GET | /drone/add | 新增页 |
| GET | /drone/edit/{id} | 编辑页 |
| POST | /drone/save | 保存 |
| POST | /drone/delete/{id} | 删除 |
| GET | /api/drones | REST 列表 |
| GET | /api/drones/{id} | REST 详情 |
