CREATE TABLE IF NOT EXISTS drone (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    drone_code VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    manufacturer VARCHAR(100),
    max_flight_time INTEGER,
    max_range DECIMAL(10,2),
    max_altitude DECIMAL(10,2),
    weight DECIMAL(10,2),
    camera_type VARCHAR(50),
    battery_capacity INTEGER,
    status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
    purchase_date DATE,
    remark VARCHAR(500),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP
);
