package com.md.basePlatform.config;

import java.io.IOException;
import javax.sql.DataSource;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

/**
 * 数据库初始化配置。
 */
@Configuration
@Profile("sqlite")
@RequiredArgsConstructor
public class DatabaseInitConfig {

    private final DataSource dataSource;

    /**
     * 应用启动时初始化 SQLite 表结构。
     *
     * @return 初始化标记 Bean
     * @throws IOException 读取 schema 失败时抛出
     */
    @Bean
    public Object databaseInitializer() throws IOException {
        ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
        populator.addScript(new ClassPathResource("schema.sql"));
        populator.setContinueOnError(false);
        populator.execute(dataSource);
        return new Object();
    }
}
