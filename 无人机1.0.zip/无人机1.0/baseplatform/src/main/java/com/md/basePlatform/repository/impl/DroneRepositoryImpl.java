package com.md.basePlatform.repository.impl;

import com.md.basePlatform.domain.Drone;
import com.md.basePlatform.repository.DroneRepository;
import com.md.basePlatform.repository.mapper.DroneMapper;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

/**
 * 无人机数据访问实现。
 */
@Repository
@RequiredArgsConstructor
public class DroneRepositoryImpl implements DroneRepository {

    private final DroneMapper droneMapper;

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Drone> findAll() {
        return droneMapper.findAll();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Optional<Drone> findById(Long id) {
        return Optional.ofNullable(droneMapper.findById(id));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int insert(Drone drone) {
        return droneMapper.insert(drone);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int update(Drone drone) {
        return droneMapper.update(drone);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int deleteById(Long id) {
        return droneMapper.deleteById(id);
    }
}
