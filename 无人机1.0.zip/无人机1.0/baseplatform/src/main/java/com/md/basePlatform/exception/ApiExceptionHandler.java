package com.md.basePlatform.exception;

import com.md.basePlatform.controller.DroneApiController;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * REST API 全局异常处理器。
 */
@RestControllerAdvice(assignableTypes = DroneApiController.class)
public class ApiExceptionHandler {

    /**
     * 处理无人机未找到异常。
     *
     * @param ex 异常
     * @return 错误响应
     */
    @ExceptionHandler(DroneNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Map<String, Object> handleNotFound(DroneNotFoundException ex) {
        Map<String, Object> body = new HashMap<>();
        body.put("message", ex.getMessage());
        return body;
    }
}
