/**
 * 公共工具与常量包。
 */
package com.md.basePlatform.common;
