package com.md.basePlatform.service;

import com.md.basePlatform.domain.Drone;
import java.util.List;

/**
 * 无人机业务接口。
 */
public interface DroneService {

    /**
     * 查询全部无人机。
     *
     * @return 无人机列表
     */
    List<Drone> listAll();

    /**
     * 按 ID 查询无人机。
     *
     * @param id 主键
     * @return 无人机信息
     */
    Drone getById(Long id);

    /**
     * 保存无人机（新增或更新）。
     *
     * @param drone 无人机实体
     * @return 保存后的无人机
     */
    Drone save(Drone drone);

    /**
     * 删除无人机。
     *
     * @param id 主键
     */
    void delete(Long id);
}
