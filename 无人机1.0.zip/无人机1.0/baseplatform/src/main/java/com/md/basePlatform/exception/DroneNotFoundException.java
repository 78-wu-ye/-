package com.md.basePlatform.exception;

/**
 * 无人机未找到异常。
 */
public class DroneNotFoundException extends RuntimeException {

    /**
     * 构造异常。
     *
     * @param id 无人机 ID
     */
    public DroneNotFoundException(Long id) {
        super("无人机不存在: " + id);
    }
}
