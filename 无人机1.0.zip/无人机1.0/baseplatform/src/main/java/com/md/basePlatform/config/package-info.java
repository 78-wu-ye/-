/**
 * Spring 配置类包。
 */
package com.md.basePlatform.config;
