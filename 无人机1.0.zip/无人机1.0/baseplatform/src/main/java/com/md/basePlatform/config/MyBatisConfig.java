package com.md.basePlatform.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * MyBatis 配置。
 */
@Configuration
@MapperScan("com.md.basePlatform.repository.mapper")
public class MyBatisConfig {
}
