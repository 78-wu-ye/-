/**
 * 领域模型包，包含实体与表单对象。
 */
package com.md.basePlatform.domain;
