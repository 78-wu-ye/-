/**
 * 异常定义与处理包。
 */
package com.md.basePlatform.exception;
