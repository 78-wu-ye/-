package com.md.basePlatform.repository.mapper;

import com.md.basePlatform.domain.Drone;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * 无人机 MyBatis Mapper。
 */
@Mapper
public interface DroneMapper {

    /**
     * 查询全部无人机。
     *
     * @return 无人机列表
     */
    @Select("""
            SELECT id, drone_code, model, manufacturer, max_flight_time, max_range,
                   max_altitude, weight, camera_type, battery_capacity, status,
                   purchase_date, remark, create_time, update_time
            FROM drone
            ORDER BY id DESC
            """)
    @Results(id = "droneResult", value = {
            @Result(property = "droneCode", column = "drone_code"),
            @Result(property = "maxFlightTime", column = "max_flight_time"),
            @Result(property = "maxRange", column = "max_range"),
            @Result(property = "maxAltitude", column = "max_altitude"),
            @Result(property = "cameraType", column = "camera_type"),
            @Result(property = "batteryCapacity", column = "battery_capacity"),
            @Result(property = "purchaseDate", column = "purchase_date"),
            @Result(property = "createTime", column = "create_time"),
            @Result(property = "updateTime", column = "update_time")
    })
    List<Drone> findAll();

    /**
     * 按 ID 查询无人机。
     *
     * @param id 主键
     * @return 无人机信息
     */
    @Select("""
            SELECT id, drone_code, model, manufacturer, max_flight_time, max_range,
                   max_altitude, weight, camera_type, battery_capacity, status,
                   purchase_date, remark, create_time, update_time
            FROM drone WHERE id = #{id}
            """)
    @ResultMap("droneResult")
    Drone findById(Long id);

    /**
     * 新增无人机。
     *
     * @param drone 无人机实体
     * @return 影响行数
     */
    @Insert("""
            INSERT INTO drone (drone_code, model, manufacturer, max_flight_time, max_range,
                               max_altitude, weight, camera_type, battery_capacity, status,
                               purchase_date, remark, create_time, update_time)
            VALUES (#{droneCode}, #{model}, #{manufacturer}, #{maxFlightTime}, #{maxRange},
                    #{maxAltitude}, #{weight}, #{cameraType}, #{batteryCapacity}, #{status},
                    #{purchaseDate}, #{remark}, datetime('now'), datetime('now'))
            """)
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Drone drone);

    /**
     * 更新无人机。
     *
     * @param drone 无人机实体
     * @return 影响行数
     */
    @Update("""
            UPDATE drone SET drone_code = #{droneCode}, model = #{model},
                             manufacturer = #{manufacturer}, max_flight_time = #{maxFlightTime},
                             max_range = #{maxRange}, max_altitude = #{maxAltitude},
                             weight = #{weight}, camera_type = #{cameraType},
                             battery_capacity = #{batteryCapacity}, status = #{status},
                             purchase_date = #{purchaseDate}, remark = #{remark},
                             update_time = datetime('now')
            WHERE id = #{id}
            """)
    int update(Drone drone);

    /**
     * 删除无人机。
     *
     * @param id 主键
     * @return 影响行数
     */
    @Delete("DELETE FROM drone WHERE id = #{id}")
    int deleteById(Long id);
}
