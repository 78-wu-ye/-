package com.md.basePlatform.domain;

/**
 * 无人机状态枚举。
 */
public enum DroneStatus {

    AVAILABLE("可用"),
    MAINTENANCE("维修中"),
    RETIRED("已报废");

    private final String label;

    DroneStatus(String label) {
        this.label = label;
    }

    /**
     * 获取状态中文标签。
     *
     * @return 中文标签
     */
    public String getLabel() {
        return label;
    }
}
