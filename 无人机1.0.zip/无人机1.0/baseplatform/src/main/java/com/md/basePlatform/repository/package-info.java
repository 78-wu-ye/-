/**
 * 数据访问层接口包。
 */
package com.md.basePlatform.repository;
