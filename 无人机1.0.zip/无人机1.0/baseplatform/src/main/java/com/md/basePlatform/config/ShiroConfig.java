package com.md.basePlatform.config;

import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Shiro 安全配置。
 */
@Configuration
public class ShiroConfig {

    /**
     * 配置 Web 安全管理器。
     *
     * @return 安全管理器
     */
    @Bean
    public SecurityManager securityManager() {
        return new DefaultWebSecurityManager();
    }

    /**
     * 配置 Shiro 过滤器，开发阶段允许匿名访问。
     *
     * @param securityManager 安全管理器
     * @return Shiro 过滤器
     */
    @Bean
    public ShiroFilterFactoryBean shiroFilterFactoryBean(SecurityManager securityManager) {
        ShiroFilterFactoryBean factoryBean = new ShiroFilterFactoryBean();
        factoryBean.setSecurityManager(securityManager);
        Map<String, String> filterChain = new LinkedHashMap<>();
        filterChain.put("/**", "anon");
        factoryBean.setFilterChainDefinitionMap(filterChain);
        return factoryBean;
    }
}
