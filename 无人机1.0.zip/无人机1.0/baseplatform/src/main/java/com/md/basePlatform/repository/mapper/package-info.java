/**
 * MyBatis Mapper 接口包。
 */
package com.md.basePlatform.repository.mapper;
