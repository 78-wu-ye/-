package com.md.basePlatform.domain;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 无人机实体。
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Drone {

    private Long id;

    @NotBlank(message = "无人机编号不能为空")
    private String droneCode;

    @NotBlank(message = "型号不能为空")
    private String model;

    private String manufacturer;

    @Positive(message = "最大飞行时间必须大于0")
    private Integer maxFlightTime;

    private BigDecimal maxRange;

    private BigDecimal maxAltitude;

    private BigDecimal weight;

    private String cameraType;

    private Integer batteryCapacity;

    @NotNull(message = "状态不能为空")
    private DroneStatus status;

    private LocalDate purchaseDate;

    private String remark;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
