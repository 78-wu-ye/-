package com.md.basePlatform.service.impl;

import com.md.basePlatform.domain.Drone;
import com.md.basePlatform.exception.DroneNotFoundException;
import com.md.basePlatform.repository.DroneRepository;
import com.md.basePlatform.service.DroneService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 无人机业务实现。
 */
@Service
@RequiredArgsConstructor
public class DroneServiceImpl implements DroneService {

    private final DroneRepository droneRepository;

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Drone> listAll() {
        return droneRepository.findAll();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Drone getById(Long id) {
        return droneRepository.findById(id)
                .orElseThrow(() -> new DroneNotFoundException(id));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public Drone save(Drone drone) {
        if (drone.getId() == null) {
            droneRepository.insert(drone);
        } else {
            getById(drone.getId());
            droneRepository.update(drone);
        }
        return drone;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public void delete(Long id) {
        getById(id);
        droneRepository.deleteById(id);
    }
}
