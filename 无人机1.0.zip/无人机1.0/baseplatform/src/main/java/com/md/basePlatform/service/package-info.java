/**
 * 业务逻辑层接口包。
 */
package com.md.basePlatform.service;
