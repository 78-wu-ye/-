package com.md.basePlatform.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * 首页控制器。
 */
@Controller
public class IndexController {

    /**
     * 首页重定向到无人机列表。
     *
     * @return 重定向路径
     */
    @GetMapping("/")
    public String index() {
        return "redirect:/drone/list";
    }
}
