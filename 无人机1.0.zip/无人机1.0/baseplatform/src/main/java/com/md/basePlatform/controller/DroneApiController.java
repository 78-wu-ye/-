package com.md.basePlatform.controller;

import com.md.basePlatform.domain.Drone;
import com.md.basePlatform.service.DroneService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 无人机 REST API 控制器。
 */
@RestController
@RequestMapping("/api/drones")
@RequiredArgsConstructor
public class DroneApiController {

    private final DroneService droneService;

    /**
     * 查询全部无人机。
     *
     * @return 无人机列表
     */
    @GetMapping
    public List<Drone> list() {
        return droneService.listAll();
    }

    /**
     * 按 ID 查询无人机。
     *
     * @param id 主键
     * @return 无人机信息
     */
    @GetMapping("/{id}")
    public Drone getById(@PathVariable Long id) {
        return droneService.getById(id);
    }
}
