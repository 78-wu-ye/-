package com.md.basePlatform.repository;

import com.md.basePlatform.domain.Drone;
import java.util.List;
import java.util.Optional;

/**
 * 无人机数据访问接口。
 */
public interface DroneRepository {

    /**
     * 查询全部无人机。
     *
     * @return 无人机列表
     */
    List<Drone> findAll();

    /**
     * 按 ID 查询无人机。
     *
     * @param id 主键
     * @return 无人机信息
     */
    Optional<Drone> findById(Long id);

    /**
     * 新增无人机。
     *
     * @param drone 无人机实体
     * @return 影响行数
     */
    int insert(Drone drone);

    /**
     * 更新无人机。
     *
     * @param drone 无人机实体
     * @return 影响行数
     */
    int update(Drone drone);

    /**
     * 删除无人机。
     *
     * @param id 主键
     * @return 影响行数
     */
    int deleteById(Long id);
}
