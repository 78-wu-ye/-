package com.md.basePlatform.exception;

import com.md.basePlatform.controller.DroneController;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * 页面全局异常处理器。
 */
@ControllerAdvice(assignableTypes = DroneController.class)
public class PageExceptionHandler {

    /**
     * 处理无人机未找到异常。
     *
     * @param ex    异常
     * @param model 视图模型
     * @return 错误页
     */
    @ExceptionHandler(DroneNotFoundException.class)
    public String handleNotFound(DroneNotFoundException ex, Model model) {
        model.addAttribute("message", ex.getMessage());
        return "error/404";
    }
}
