package com.md.basePlatform.controller;

import com.md.basePlatform.domain.Drone;
import com.md.basePlatform.domain.DroneStatus;
import com.md.basePlatform.service.DroneService;
import jakarta.validation.Valid;
import java.util.Arrays;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * 无人机页面控制器。
 */
@Controller
@RequestMapping("/drone")
@RequiredArgsConstructor
public class DroneController {

    private final DroneService droneService;

    /**
     * 无人机列表页。
     *
     * @param model 视图模型
     * @return 模板路径
     */
    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("drones", droneService.listAll());
        return "drone/list";
    }

    /**
     * 新增页面。
     *
     * @param model 视图模型
     * @return 模板路径
     */
    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("drone", new Drone());
        model.addAttribute("statuses", Arrays.asList(DroneStatus.values()));
        model.addAttribute("formTitle", "新增无人机");
        return "drone/form";
    }

    /**
     * 编辑页面。
     *
     * @param id    主键
     * @param model 视图模型
     * @return 模板路径
     */
    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("drone", droneService.getById(id));
        model.addAttribute("statuses", Arrays.asList(DroneStatus.values()));
        model.addAttribute("formTitle", "编辑无人机");
        return "drone/form";
    }

    /**
     * 保存无人机。
     *
     * @param drone              表单数据
     * @param bindingResult      校验结果
     * @param redirectAttributes 重定向属性
     * @return 重定向路径
     */
    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("drone") Drone drone,
                       BindingResult bindingResult,
                       Model model,
                       RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("statuses", Arrays.asList(DroneStatus.values()));
            model.addAttribute("formTitle", drone.getId() == null ? "新增无人机" : "编辑无人机");
            return "drone/form";
        }
        droneService.save(drone);
        redirectAttributes.addFlashAttribute("message", "保存成功");
        return "redirect:/drone/list";
    }

    /**
     * 删除无人机。
     *
     * @param id                 主键
     * @param redirectAttributes 重定向属性
     * @return 重定向路径
     */
    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        droneService.delete(id);
        redirectAttributes.addFlashAttribute("message", "删除成功");
        return "redirect:/drone/list";
    }
}
