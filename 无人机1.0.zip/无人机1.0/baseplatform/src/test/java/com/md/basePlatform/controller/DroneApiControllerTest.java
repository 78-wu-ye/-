package com.md.basePlatform.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.md.basePlatform.domain.Drone;
import com.md.basePlatform.domain.DroneStatus;
import com.md.basePlatform.repository.mapper.DroneMapper;
import com.md.basePlatform.service.DroneService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.mybatis.spring.boot.autoconfigure.MybatisAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

/**
 * 无人机 REST 控制器测试。
 */
@WebMvcTest(controllers = DroneApiController.class,
        excludeAutoConfiguration = {MybatisAutoConfiguration.class, DataSourceAutoConfiguration.class})
@AutoConfigureMockMvc(addFilters = false)
class DroneApiControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DroneService droneService;

    @MockBean
    private DroneMapper droneMapper;

    @Test
    void should_return_json_list_when_request_api() throws Exception {
        when(droneService.listAll()).thenReturn(List.of(
                Drone.builder().id(1L).droneCode("DR-001").model("M300")
                        .status(DroneStatus.AVAILABLE).build()
        ));

        mockMvc.perform(get("/api/drones"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].droneCode").value("DR-001"));
    }
}
