package com.md.basePlatform.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.md.basePlatform.domain.Drone;
import com.md.basePlatform.domain.DroneStatus;
import com.md.basePlatform.exception.DroneNotFoundException;
import com.md.basePlatform.repository.DroneRepository;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * 无人机业务层单元测试。
 */
@ExtendWith(MockitoExtension.class)
class DroneServiceImplTest {

    @Mock
    private DroneRepository droneRepository;

    @InjectMocks
    private DroneServiceImpl droneService;

    @Test
    void should_return_all_drones_when_list_all() {
        when(droneRepository.findAll()).thenReturn(List.of(sampleDrone()));

        List<Drone> result = droneService.listAll();

        assertThat(result).hasSize(1);
    }

    @Test
    void should_return_drone_when_get_by_id_exists() {
        when(droneRepository.findById(1L)).thenReturn(Optional.of(sampleDrone()));

        Drone result = droneService.getById(1L);

        assertThat(result.getDroneCode()).isEqualTo("DR-001");
    }

    @Test
    void should_throw_exception_when_get_by_id_not_found() {
        when(droneRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> droneService.getById(99L))
                .isInstanceOf(DroneNotFoundException.class);
    }

    @Test
    void should_insert_drone_when_save_new() {
        Drone drone = sampleDrone();
        drone.setId(null);
        when(droneRepository.insert(any(Drone.class))).thenReturn(1);

        Drone saved = droneService.save(drone);

        assertThat(saved.getDroneCode()).isEqualTo("DR-001");
        verify(droneRepository).insert(drone);
    }

    @Test
    void should_update_drone_when_save_existing() {
        Drone drone = sampleDrone();
        when(droneRepository.findById(1L)).thenReturn(Optional.of(drone));
        when(droneRepository.update(drone)).thenReturn(1);

        droneService.save(drone);

        verify(droneRepository).update(drone);
    }

    @Test
    void should_delete_drone_when_exists() {
        when(droneRepository.findById(1L)).thenReturn(Optional.of(sampleDrone()));

        droneService.delete(1L);

        verify(droneRepository).deleteById(1L);
    }

    private Drone sampleDrone() {
        return Drone.builder()
                .id(1L)
                .droneCode("DR-001")
                .model("M300")
                .manufacturer("DJI")
                .status(DroneStatus.AVAILABLE)
                .build();
    }
}
