cd c:\Users\Lenovo\Desktop\cupro\baseplatform
.\mvnw.cmd spring-boot:run